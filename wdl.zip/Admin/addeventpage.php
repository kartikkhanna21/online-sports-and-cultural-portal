<?php
include '../connect.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>ADD EVENT PAGE</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="../main.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

</head>
<body>


  
<section class="addeventform">
  <div id="div55">
    <div class="container">
      <!-- <div class="row">
        <div class="col-2 col-md-3">
        </div>
        <div class="col-8 col-md-6 formtop">ADD EVENT Details</div>
        <div class="col-2 col-md-3">
        </div>
      </div> -->
      <div class="row">
        <div class="col-2 col-md-3"></div>
        <div class="col-8 col-md-6" id="colorform">
          <div class="d-flex justify-content-center formtop">ADD EVENT Details</div>
          <form action="add_event.php" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <input type="text" class="form-control" name="ename" placeholder="Event Name">
              </div>
              <div class="form-group">
                <textarea name="edesc" class="form-control" rows="10" cols="30" placeholder="Event Description"></textarea>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="eorganizer" placeholder="Event Organizer">
              </div>
              <div class="form-group">
                Group Event
                <input type="radio" id="yes" name="gevent" value="1">
                <label for="yes">Yes</label>
                <input type="radio" id="no" name="gevent" value="0">
                <label for="no">No</label><br>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="max_p" placeholder="Maximum Participants">
            </div>
              <div class="form-group">
                <input type="date" class="form-control" name="edate" placeholder="DD-MM-YY">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="efee" placeholder="Event Fee">
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="form-group">
                    <input class="form-control" type="file" id="img" name="photo" accept="image/x-png,image/jpeg" >
                    <label class="custom-file-label" for="img">Event Image</label>
                  </div>
                </div>
              </div>
              
              <div class="form-group">
                <div class="d-flex justify-content-center"><button class="btn btn-primary" type="submit" value="submit" name="addevent">ADD EVENT</button></div>
              </div>
          </form>
        </div>
        <div class="col-2 col-md-3"></div>
      </div>
    </div>
  </div>
</section>
<section class="side_nav">
  <nav class="main-menu ">  
    <div class="scrollbar" id="style-1">     
    <ul>
      <div class="adj_top_side-nav logo"><!-- logo --></div>
      <li>                                   
        <a href="aindex.html">
        <i class="fa fa-2x fa-home"></i>
        <span class="nav-text">Home</span>
        </a>
      </li>         
      <li>                                 
        <a href="ResultDeclaration.html">
        <i class="fa fa-2x fa-trophy"></i>
        <span class="nav-text">Result</span>
        </a>
      </li> 
      <li>                                 
        <a href="aprofile.html">
        <i class="fa fa-2x fa-user"></i>
        <span class="nav-text">Profile</span>
        </a>
      </li>   
      <li>                                 
        <a href="aTable.html">
        <i class="fa fa-2x fa-table"></i>
        <span class="nav-text">Table</span>
        </a>
      </li>
      <li>                                 
        <a href="addeventpage.php">
        <i class="fa fa-plus-square-o fa-2x"></i>
        <span class="nav-text">Add Event</span>
        </a>
      </li>
      <li>                                 
        <a href="#">
        <i class="fa fa-2x fa-sign-out"></i>
        <span class="nav-text">Logout</span>
        </a>
      </li>    
    </ul>         
  </nav>
</section>  
</body>
</html>
<!-- 
  after share
<div class="addthis_default_style addthis_32x32_style">
<div style="position:absolute;
 margin-left: 56px;top:3px;"> 
 Event name
 Description
 location
 date
 fee
 img

--> 