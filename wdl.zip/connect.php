<?php
// DONT UNCOMMENT THIS

$url = "C:\\xampp\htdocs\\wdl";

//CAN COMMENT OUT BELOW

	$hostname="localhost"; //hostname
	$username="root"; //username for database
	$password=""; //database password
	$dbname="wdl"; //database name
	//$dbnamerev="transcriptrev";
	$connect=mysqli_connect($hostname,$username,$password,$dbname);
    //$connectrev=mysqli_connect($hostname,$username,$password,$dbnamerev);
	//echo  "dfd";
?>