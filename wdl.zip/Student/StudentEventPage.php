<?php
include '../connect.php';
?>
<!DOCTYPE html>

<html>
<head>
  <title>Student Event Page</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="../main.css">
  <link rel="stylesheet" type="text/css" href="studenteventpage.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

</head>
<body>


<?php
$sql="SELECT * from `add_event`";
$setRec = mysqli_query($connect, $sql);
while($row = mysqli_fetch_array($setRec)){
$eimg="../Photos/".$row['event_image'];


?>
<section class="smainevent">
  <div id="div55">
    <div class="container">
      <div id="indivevent">
        <div class="row">
          <div class="col-2 col-md-3"></div>
          <div class="col-8 col-md-6">
            <div class="card cardwidth" ><!-- style="width: 18rem;" -->
              <img src="<?php echo $eimg;?>" class="card-img-top img-fluid rounded" id="eventbanner" alt="Eventposter">
              <div class="card-body">
                <h5 class="card-title crdmarg ch5"><span id="eventname"><b><?php echo $row['event_name'];?></b><span></h5>
                <p class="card-text crdmarg"><span id="description"><?php echo $row['event_description'];?></span></p>
                <p class="card-text crdmarg"><span id="eventdate"><b>Date of event: </b><?php echo $row['event_date'];?></span></p>
                <p class="card-text crdmarg"><span id="fee"><b>Participation Fees: </b><?php echo $row['event_fee'];?></span></p>
                <div class="row">
                  <div class="col-2 col-sm-3"></div>
                  <div class="col-8 col-sm-6">  
                    <a href="#" class="btn btn-primary btnfix">Participate</a>
                  </div>
                  <div class="col-2 col-sm-3"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-2 col-md-3"></div>
        </div>
      </div>
      <?php
      }
      ?>
      <div id="indivevent1">
        <div class="row">
          <div class="col-2 col-md-3"></div>
          <div class="col-8 col-md-6">
            <div class="card cardwidth" ><!-- style="width: 18rem;" -->
              <img src="https://images.unsplash.com/photo-1600770049974-d94fcd4fcc17?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80" class="card-img-top img-fluid rounded" id="eventbanner" alt="Eventposter">
              <div class="card-body">
                <h5 class="card-title crdmarg ch5"><span id="eventname">Event Name<span></h5>
                <p class="card-text crdmarg"><span id="describtion">its a 20-20 cric match with 11 players in each team.each team will have to score maximum runs to win the match.</span></p>
                <p class="card-text crdmarg"><span id="eventdate">01/01/2020</span></p>
                <p class="card-text crdmarg"><span id="fee">$100000</span></p>
                <div class="row">
                  <div class="col-2 col-sm-3"></div>
                  <div class="col-8 col-sm-6">  
                    <a href="https://www.google.com/" class="btn btn-primary btnfix">Participate</a>
                  </div>
                  <div class="col-2 col-sm-3"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-2 col-md-3"></div>
        </div>
      </div>
      <div id="indivevent2">
        <div class="row">
          <div class="col-2 col-md-3"></div>
          <div class="col-8 col-md-6">
            <div class="card cardwidth" ><!-- style="width: 18rem;" -->
              <img src="https://images.unsplash.com/photo-1600770049974-d94fcd4fcc17?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80" class="card-img-top img-fluid rounded" id="eventbanner" alt="Eventposter">
              <div class="card-body">
                <h5 class="card-title crdmarg ch5"><span id="eventname">Event Name<span></h5>
                <p class="card-text crdmarg"><span id="describtion">its a 20-20 cric match with 11 players in each team.each team will have to score maximum runs to win the match.</span></p>
                <p class="card-text crdmarg"><span id="eventdate">01/01/2020</span></p>
                <p class="card-text crdmarg"><span id="fee">$100000</span></p>
                <div class="row">
                  <div class="col-2 col-sm-3"></div>
                  <div class="col-8 col-sm-6">  
                    <a href="https://www.google.com/" class="btn btn-primary btnfix">Participate</a>
                  </div>
                  <div class="col-2 col-sm-3"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-2 col-md-3"></div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="side_nav">
  <nav class="main-menu ">  
    <div class="scrollbar" id="style-1">     
    <ul>
      <div class="adj_top_side-nav logo"><!-- logo --></div>
      <li>                                   
        <a href="sindex.html">
        <i class="fa fa-2x fa-home"></i>
        <span class="nav-text">Home</span>
        </a>
      </li>           
      <li>                                 
        <a href="StudentEventPage.php">
        <i class="fa fa-calendar fa-2x"></i>
        <span class="nav-text">Event page</span>
        </a>
      </li> 
      <li>                                 
        <a href="sprofile.html">
        <i class="fa fa-2x fa-user"></i>
        <span class="nav-text">Profile</span>
        </a>
      </li> 
      <li>                                 
        <a href="certificate.html">
        <i class="fa fa-2x fa-certificate"></i>
        <span class="nav-text">Certificate</span>
        </a>
      </li>  
      <li>                                 
        <a href="#">
        <i class="fa fa-2x fa-sign-out"></i>
        <span class="nav-text">Logout</span>
        </a>
      </li>    
    </ul>         
  </nav>
</section>
</body>
</html>
